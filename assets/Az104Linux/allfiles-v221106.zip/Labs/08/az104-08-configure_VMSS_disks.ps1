$rgName = 'az104-08-rg02'
$vmssName = 'az10408vmss0'
$vmss = Get-AzVmss `
	-ResourceGroupName $rgName `
	-VMScaleSetName $vmssName

$publicSettings = @{
	"fileUris" = (,"https://raw.githubusercontent.com/Azure-Samples/compute-automation-configurations/master/prepare_vm_disks.sh");
	"commandToExecute" = "./prepare_vm_disks.sh"
}

Add-AzVmssExtension -VirtualMachineScaleSet $vmss `
	-Name "customScript" `
	-Publisher "Microsoft.Azure.Extensions" `
	-Type "CustomScript" `
	-TypeHandlerVersion 2.0 `
	-Setting $publicSettings

# Update the scale set and apply the Custom Script Extension to the VM instances
Update-AzVmss `
	-ResourceGroupName $rgName `
	-Name $vmssName `
	-VirtualMachineScaleSet $vmss