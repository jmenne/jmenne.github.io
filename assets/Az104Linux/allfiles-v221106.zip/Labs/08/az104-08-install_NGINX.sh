sudo apt-get install -y nginx
echo 'Hello World from host' $(hostname)'!' | sudo tee -a /var/www/html/index.html